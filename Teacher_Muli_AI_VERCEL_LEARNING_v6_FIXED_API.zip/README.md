# Teacher Muli AI — Vercel Learning v6

PP1–Grade 9 learner app with working dashboard controls, manual KSh 10 / 24-hour payment approval, AI Q&A, voice input/output, homework photo solving, homework/assignment help, notes, quizzes, and downloads.

Required Vercel Production environment variables:
- SUPABASE_URL
- SUPABASE_SERVICE_ROLE_KEY (or Supabase Secret Key used as the server credential)
- OPENAI_API_KEY

Optional:
- OPENAI_MODEL (defaults to gpt-6-luna)

Do not expose server secrets in frontend code.
