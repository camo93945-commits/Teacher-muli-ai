import {json,sb,deviceId,newDeviceCookie} from './_lib.js';
export default async function handler(req){
  if(req.method!=='POST') return json({error:'method_not_allowed'},405);
  try{
    const body=await req.json().catch(()=>({}));
    const reference=String(body.reference||'').trim().replace(/\s+/g,' ');
    if(!reference) return json({error:'reference_required'},400);
    if(reference.length>100) return json({error:'reference_too_long'},400);
    const id=deviceId(req)||crypto.randomUUID();
    // One database request only: the unique index on lower(reference) handles duplicates.
    await sb('tm_payment_requests',{method:'POST',headers:{Prefer:'return=minimal'},body:JSON.stringify({device_id:id,reference,amount:10,status:'PENDING'})});
    return json({ok:true,status:'PENDING'},200,{'Set-Cookie':newDeviceCookie(id)});
  }catch(e){
    const raw=JSON.stringify(e.detail??e.message??'').toLowerCase();
    const duplicate=e.status===409||raw.includes('duplicate')||raw.includes('unique');
    const status=duplicate?409:e.code==='SUPABASE_TIMEOUT'?504:500;
    return json({error:duplicate?'duplicate_reference':'payment_request_failed',code:e.code||null,supabaseStatus:e.status||null,detail:e.detail||e.message||'Unknown server error'},status);
  }
}
